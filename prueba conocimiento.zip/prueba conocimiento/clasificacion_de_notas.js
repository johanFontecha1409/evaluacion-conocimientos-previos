class notas {
    constructor(nombre, genero, materia, notas) {
         
        this.nombre = nombre;
        this.genero = genero;
        this.materia = materia;
        this.notas = notas;
        
    }

}
mostrarNotas(); {

    document.write("nombre:" + this.nombre + "genero:" + this.genero + "materia:" + this.materia + "notas:" + this.notas);

        if (this.notas >= 4.5) {
            document.write("excelente");
        }
        else if (this.notas >= 3.5 && this.notas < 4.5) {
            document.write("sobresaliente");
        }
        else if (this.notas >= 2.5 && this.notas < 3.5) {
            document.write("regular");
        }
        else if (this.notas >= 1.0 && this.notas < 2.5) {
            document.write("insuficiente");
        }
        else (this.notas = 0.0 && this.notas < 1.0) {
            document.write("deficiente");
        }

}

new notas("juan", "masculino", "matematicas", [1.5, 3.0, 5.0]);
new notas("juan", "masculino", "idioma", [4.0, 2.7, 3.5]);
new notas("maria", "femenino", "matematicas", [3.5, 4.0, 3.3]);
new notas("maria", "femenino", "idioma", [4.0, 4.5, 3.5]);
new notas("pedro", "masculino", "matematicas", [3.5, 4.0, 4.5]);  
new notas("pedro", "masculino", "idioma", [4.0, 4.5, 3.5]);   


